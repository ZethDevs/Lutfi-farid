<div align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Inconsolata&weight=500&size=50&duration=2000&pause=300&color=A7A459&center=true&vCenter=true&multiline=true&repeat=false&random=false&width=1300&height=140&lines=Hello+hello;I'm+Radithya_Mahesa!%2C+a+code+enthusiast+%E2%9C%A9" width="100%" />

<a href="https://youtu.be/xvFZjo5PgG0?si=TJnsdGZkvts92mET"><img src="radit.webp"></a>
  
  <img src="hutao-waving.webp" alt="Banner" width="100%">
  <p></p>
  

<div align="left">
    <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=500&duration=3500&pause=1000&color=F73D38&random=false&width=435&lines=I'm+currently+a+student+%3A);Of+Course+Im+still+an+Amateur;But+I'll+try+to+do+better++(%E2%81%A0%EF%BD%A1%E2%81%A0%E2%80%A2%CC%80%E2%81%A0%E1%B4%97%E2%81%A0-%E2%81%A0)%E2%81%A0%E2%9C%A7;I+hope+so...">
</div>

<a href="https://youtu.be/xvFZjo5PgG0?si=TJnsdGZkvts92mET"><img src="radit.webp"></a>

### Feel Free To Connect me 📫:
<p align="center">
  <a href="https://www.instagram.com/rdthymhsa" target="_blank"><img src="https://img.shields.io/badge/rdthymhsa-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white"></a>
  <a href="https://twitter.com/Radithya_Mahesa" target="_blank"><img src="https://img.shields.io/badge/Radithya%5FMahesa-%23000000.svg?style=for-the-badge&logo=X&logoColor=white" alt="Twitter"></a>
  <a href="https://www.facebook.com/radithya.mahesasyabil.1" target="_blank"><img src="https://img.shields.io/badge/Radithya%20MS-%231877F2.svg?style=for-the-badge&logo=Facebook&logoColor=white" alt="Facebook"></a>
  <a href="https://open.spotify.com/user/6neymqajcyxvsm9dp7pexge6o" target="_blank"><img src="https://img.shields.io/badge/WakeUpRadit-1ED760?style=for-the-badge&logo=spotify&logoColor=white" alt="Spotify"></a>
</p>
</Div>
 <a href="https://youtu.be/xvFZjo5PgG0?si=TJnsdGZkvts92mET"><img src="radit.webp"></a>

### What I use 📌:
<p align="center">
  <img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white">
  <img src="https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white">
  <img src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E">
</p>
<p align="center">
  <img src="https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white">
  <img src="https://img.shields.io/badge/kotlin-%237F52FF.svg?style=for-the-badge&logo=kotlin&logoColor=white">
</p>
<p align="center">
  <img src="https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54">
  <img src="https://img.shields.io/badge/php-%23777BB4.svg?style=for-the-badge&logo=php&logoColor=white">
  <img src="https://img.shields.io/badge/c-%2300599C.svg?style=for-the-badge&logo=c&logoColor=white">
</p>
<p align="center">
  <img src="https://img.shields.io/badge/apache-%23D42029.svg?style=for-the-badge&logo=apache&logoColor=white">
  <img src="https://img.shields.io/badge/mysql-4479A1.svg?style=for-the-badge&logo=mysql&logoColor=white">
  <img src="https://img.shields.io/badge/MariaDB-003545?style=for-the-badge&logo=mariadb&logoColor=white">
</p>
<p align="center">
  <img src="https://img.shields.io/badge/bootstrap-%238511FA.svg?style=for-the-badge&logo=bootstrap&logoColor=white">
  <img src="https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white">
</p>
<p align="center">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/Figma/figma1.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/AndroidStudio/androidstudio3.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/VisualStudioCode/visualstudiocode1.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/IDEA/idea2.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/Git/git3.svg">
</p>
<p align="center">
    <img src="https://img.shields.io/badge/Edge-0078D7?style=for-the-badge&logo=Microsoft-edge&logoColor=white">
    <img src="https://img.shields.io/badge/Firefox-FF7139?style=for-the-badge&logo=Firefox-Browser&logoColor=white">
    <img src="https://img.shields.io/badge/Google%20Chrome-4285F4?style=for-the-badge&logo=GoogleChrome&logoColor=white">
</p>
<p align="center">
    <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/Windows/windows1.svg">
</p>

<a href="https://youtu.be/xvFZjo5PgG0?si=TJnsdGZkvts92mET"><img src="radit.webp"></a>

### Github Stats 📊 :
<p align="left">
  <img width=50% src="https://github-readme-stats.vercel.app/api?username=radithya-mahesa&show_icons=true&theme=synthwave">
  <img width=50% src="https://github-readme-stats.vercel.app/api/top-langs/?username=radithya-mahesa&layout=compact">
</p>

<a href="https://youtu.be/xvFZjo5PgG0?si=TJnsdGZkvts92mET"><img src="radit.webp"></a>

### Music is Everything 🎧 :
<div align="center">
  <a href="https://open.spotify.com/user/6neymqajcyxvsm9dp7pexge6o?si=893cdcdd1fa148d8" target="_blank"><img src="https://spotify-github-profile.vercel.app/api/view.svg?uid=6neymqajcyxvsm9dp7pexge6o&redirect=true][https://spotify-github-profile.vercel.app/api/view.svg?uid=6neymqajcyxvsm9dp7pexge6o&cover_image=true&theme=novatorem&show_offline=true&background_color=121212&interchange=false&bar_color=c3dc04&bar_color_cover=false"><br>
  <img src="https://spotify-recently-played-readme.vercel.app/api?user=6neymqajcyxvsm9dp7pexge6o&count=3" alt="Spotify Recently Played">
</div>
